package model.bean;

public class LichTrinh {

	private String maLichTrinh;
	private String diemDi;
	private String diemDen;
	private String maGiaVe;
	private String thoiGianChay;
	private String quangDuong;
	private String tinhTrang;

	public String getTinhTrang() {
		return tinhTrang;
	}

	public void setTinhTrang(String tinhTrang) {
		this.tinhTrang = tinhTrang;
	}

	public String getMaLichTrinh() {
		return maLichTrinh;
	}

	public void setMaLichTrinh(String maLichTrinh) {
		this.maLichTrinh = maLichTrinh;
	}

	public String getDiemDi() {
		return diemDi;
	}

	public void setDiemDi(String diemDi) {
		this.diemDi = diemDi;
	}

	public String getDiemDen() {
		return diemDen;
	}

	public String getMaGiaVe() {
		return maGiaVe;
	}

	public void setMaGiaVe(String maGiaVe) {
		this.maGiaVe = maGiaVe;
	}

	public String getThoiGianChay() {
		return thoiGianChay;
	}

	public void setThoiGianChay(String thoiGianChay) {
		this.thoiGianChay = thoiGianChay;
	}

	public String getQuangDuong() {
		return quangDuong;
	}

	public void setQuangDuong(String quangDuong) {
		this.quangDuong = quangDuong;
	}

	public void setDiemDen(String diemDen) {
		this.diemDen = diemDen;
	}

}
