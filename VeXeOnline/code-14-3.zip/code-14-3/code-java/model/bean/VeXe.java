package model.bean;

public class VeXe {

	private String maVeXe;
	private int soLuongVe;
	private String ngayDi;

	public String getMaVeXe() {
		return maVeXe;
	}

	public void setMaVeXe(String maVeXe) {
		this.maVeXe = maVeXe;
	}

	public int getSoLuongVe() {
		return soLuongVe;
	}

	public void setSoLuongVe(int soLuongVe) {
		this.soLuongVe = soLuongVe;
	}

	public String getNgayDi() {
		return ngayDi;
	}

	public void setNgayDi(String ngayDi) {
		this.ngayDi = ngayDi;
	}

}
