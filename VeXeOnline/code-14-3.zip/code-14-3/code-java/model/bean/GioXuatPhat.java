package model.bean;

public class GioXuatPhat {

	private String gioXuatPhat;

	public GioXuatPhat(String gioXuatPhat) {
		super();
		this.gioXuatPhat = gioXuatPhat;
	}

	public GioXuatPhat() {
		super();
	}

	public String getGioXuatPhat() {
		return gioXuatPhat;
	}

	public void setGioXuatPhat(String gioXuatPhat) {
		this.gioXuatPhat = gioXuatPhat;
	}

}
