package model.bean;

public class GiaVe {

	private String maGiaVe;
	private float giaVe;
	private String giaVeString;

	public String getMaGiaVe() {
		return maGiaVe;
	}

	public void setMaGiaVe(String maGiaVe) {
		this.maGiaVe = maGiaVe;
	}

	public float getGiaVe() {
		return giaVe;
	}

	public void setGiaVe(float giaVe) {
		this.giaVe = giaVe;
	}

	public String getGiaVeString() {
		return giaVeString;
	}

	public void setGiaVeString(String giaVeString) {
		this.giaVeString = giaVeString;
	}

}
