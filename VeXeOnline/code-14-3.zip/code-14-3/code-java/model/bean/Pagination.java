package model.bean;

public class Pagination {
	  public static int page;
	  public static int totalPage;
}
