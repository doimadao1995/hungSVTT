package model.bean;

public class DiemTraKhach {

	private String maDiemTraKhach;
	private String diemTraKhach;

	public String getMaDiemTraKhach() {
		return maDiemTraKhach;
	}

	public void setMaDiemTraKhach(String maDiemTraKhach) {
		this.maDiemTraKhach = maDiemTraKhach;
	}

	public String getDiemTraKhach() {
		return diemTraKhach;
	}

	public void setDiemTraKhach(String diemTraKhach) {
		this.diemTraKhach = diemTraKhach;
	}

}
