package model.bean;

public class DiemDonKhach {

	private String maDiemDonKhach;
	private String diemDonKhach;

	public String getMaDiemDonKhach() {
		return maDiemDonKhach;
	}

	public void setMaDiemDonKhach(String maDiemDonKhach) {
		this.maDiemDonKhach = maDiemDonKhach;
	}

	public String getDiemDonKhach() {
		return diemDonKhach;
	}

	public void setDiemDonKhach(String diemDonKhach) {
		this.diemDonKhach = diemDonKhach;
	}

}
